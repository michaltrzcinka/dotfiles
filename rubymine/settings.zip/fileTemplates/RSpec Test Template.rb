#parse("Ruby File Header.rb")

require 'spec_helper'

describe ${Described_class} do
  
end